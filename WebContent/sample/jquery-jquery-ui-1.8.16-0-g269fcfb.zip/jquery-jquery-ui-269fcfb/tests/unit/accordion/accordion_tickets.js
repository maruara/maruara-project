/*
 * accordion_tickets.js
 */
(function($) {

module("accordion: tickets");

})(jQuery);
